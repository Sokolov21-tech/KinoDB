<?php
// ---- База данных --------------------------------------------------
define('DB_HOST',     'localhost');
define('DB_PORT',     3306);
define('DB_NAME',     'kino_db');
define('DB_USER',     'root');
define('DB_PASS',     '');
define('DB_CHARSET',  'utf8mb4');

// ---- Настройки сайта -----------------------------------------------
define('APP_NAME',    'KinoDB');
define('APP_URL',     getenv('APP_URL') ?: 'http://localhost/kino');
define('APP_VERSION', '1.0.0');
define('APP_ENV',     getenv('APP_ENV') ?: 'development'); // 'development' | 'production'

// ---- Сессия ---------------------------------------------------
define('SESSION_LIFETIME',   86400);     // в секундах
define('SESSION_COOKIE_NAME', 'kino_sess');

// ---- Безопасность --------------------------------------------------
define('CSRF_TOKEN_LENGTH',    32);
define('PASSWORD_MIN_LENGTH',   8);
define('LOGIN_MAX_ATTEMPTS',    5);
define('LOGIN_LOCKOUT_MINUTES', 15);
define('TOKEN_EXPIRY_HOURS',   24);      // верификация почты / смена пароля

// ---- Загрузка файлов -----------------------------------------------
define('UPLOAD_MAX_SIZE',   5 * 1024 * 1024);   // 5 MB
define('UPLOAD_DIR',        __DIR__ . '/../assets/uploads/');
define('UPLOAD_URL',        APP_URL . '/assets/uploads/');
define('ALLOWED_IMAGE_TYPES', ['image/jpeg','image/png','image/webp']);

// ---- TMDB API --------------------------------------------------
define('TMDB_API_KEY',     getenv('TMDB_API_KEY') ?: 'c805ac107656575c7998c89a8990a279');
define('TMDB_BASE_URL',    'https://movie.masatov.xyz/api/tmdb-proxy.php');
define('TMDB_FALLBACK_BASE_URL', getenv('TMDB_FALLBACK_BASE_URL') ?: 'https://api.tmdb.org/3');
define('TMDB_IMAGE_URL',   'https://image.tmdb.org/t/p/');
$tmdbImageProxyEnv = getenv('TMDB_IMAGE_PROXY_ENABLED');
define('TMDB_IMAGE_PROXY_ENABLED', $tmdbImageProxyEnv === false ? true : filter_var($tmdbImageProxyEnv, FILTER_VALIDATE_BOOLEAN));
define('TMDB_IMAGE_PROXY_URL', 'https://movie.masatov.xyz/api/tmdb-image.php');

// ---- OMDB API ----------------------------------------
define('OMDB_API_KEY',     'YOUR_OMDB_API_KEY');
define('OMDB_BASE_URL',    'https://www.omdbapi.com/');

// ---- Email / SMTP ----------------------------------------------
define('MAIL_HOST',       'smtp.gmail.com');
define('MAIL_PORT',        587);
define('MAIL_USERNAME',   'your@gmail.com');
define('MAIL_PASSWORD',   'your_app_password');
define('MAIL_FROM_EMAIL', 'no-reply@kinodb.local');
define('MAIL_FROM_NAME',  'KinoDB');
define('MAIL_USE_TLS',    true);
define('MAIL_DEBUG',      APP_ENV === 'development');

// ---- Минимальная защита от DDOS ---------------------------
define('RATE_LIMIT_WINDOW',   60);      // seconds
define('RATE_LIMIT_MAX_API',  60);      // API requests per window
define('RATE_LIMIT_MAX_AUTH', 10);      // auth attempts per window
define('RATE_LIMIT_MAX_PAGE', 120);     // page requests per window

// ---- Пути -----------------------------------------------------
define('ROOT_PATH',   dirname(__DIR__));
define('LOG_PATH',    ROOT_PATH . '/logs/');
define('CACHE_PATH',  ROOT_PATH . '/cache/');
define('TMDB_IMAGE_CACHE_DIR', CACHE_PATH . 'tmdb-images/');
define('TMDB_IMAGE_CACHE_TTL', 30 * 24 * 60 * 60); // 30 days
define('TMDB_IMAGE_MAX_BYTES', 15 * 1024 * 1024);  // 15 MB

// ---- Запуск ---------------------------------------------------
date_default_timezone_set('Europe/Moscow');
mb_internal_encoding('UTF-8');

if (APP_ENV === 'development') {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}

// Логи
if (!is_dir(LOG_PATH)) {
    mkdir(LOG_PATH, 0750, true);
}
