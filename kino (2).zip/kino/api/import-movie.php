<?php
 
require_once dirname(__DIR__) . '/includes/config.php';
require_once dirname(__DIR__) . '/includes/db.php';
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/security.php';

startSession();
header('Content-Type: application/json; charset=utf-8');

if (!isAjax()) {
     
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action'])) {
        requireAdmin();
    } else {
        http_response_code(403);
        die(eJson(['error' => 'AJAX only']));
    }
}

requireAdmin();
rateLimitOrDie('api_import', 30);

 
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'search') {
    $q = sanitizeString($_GET['q'] ?? '', 200);
    if (!$q) jsonResponse(['results' => []]);
    $data = tmdbRequest('/search/movie', ['query' => $q, 'language' => 'ru-RU']);
    jsonResponse($data ?? ['results' => [], 'error' => tmdbLastError()]);
}

 
$body  = json_decode(file_get_contents('php://input'), true) ?? [];
$token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
    jsonResponse(['error' => 'CSRF'], 403);
}

$tmdbId   = sanitizeInt($body['tmdb_id'] ?? 0);
$language = in_array($body['language'] ?? '', ['ru-RU','en-US']) ? $body['language'] : 'ru-RU';

if (!$tmdbId) jsonResponse(['ok' => false, 'error' => 'TMDB ID обязателен'], 400);

 
$existing = dbFetch("SELECT id, title FROM movies WHERE tmdb_id = :id", ['id' => $tmdbId]);
if ($existing) {
    jsonResponse(['ok' => false, 'error' => "Уже импортирован: {$existing['title']} (ID {$existing['id']})"]);
}

if (TMDB_API_KEY === 'YOUR_TMDB_API_KEY') {
    jsonResponse(['ok' => false, 'error' => 'TMDB_API_KEY не настроен в config.php']);
}

 
$movie = tmdbRequest("/movie/$tmdbId", ['language' => $language, 'append_to_response' => 'credits,external_ids']);
if (!$movie || empty($movie['id'])) {
    $reason = tmdbLastError();
    if ($reason) {
        jsonResponse(['ok' => false, 'error' => 'TMDB не вернул фильм: ' . $reason]);
    }
    jsonResponse(['ok' => false, 'error' => 'Фильм не найден в TMDB']);
}

 
$countryCode = $movie['production_countries'][0]['iso_3166_1'] ?? null;
$countryId   = null;
if ($countryCode) {
    $c = dbFetch("SELECT id FROM countries WHERE code = :code", ['code' => $countryCode]);
    if (!$c) {
        $countryName = $movie['production_countries'][0]['name'] ?? $countryCode;
        $countryId   = dbInsert('countries', ['name' => $countryName, 'code' => $countryCode]);
    } else {
        $countryId = $c['id'];
    }
}

 
$movieId = dbInsert('movies', [
    'title'          => $movie['title']            ?? $movie['original_title'] ?? '',
    'original_title' => $movie['original_title']   ?? null,
    'description'    => $movie['overview']         ?? null,
    'release_year'   => substr($movie['release_date'] ?? '', 0, 4) ?: null,
    'release_date'   => $movie['release_date']     ?: null,
    'duration'       => $movie['runtime']          ?: null,
    'poster_url'     => $movie['poster_path']      ? TMDB_IMAGE_URL . 'w500'    . $movie['poster_path']   : null,
    'backdrop_url'   => $movie['backdrop_path']    ? TMDB_IMAGE_URL . 'original' . $movie['backdrop_path'] : null,
    'country_id'     => $countryId,
    'imdb_id'        => $movie['external_ids']['imdb_id'] ?? null,
    'tmdb_id'        => $tmdbId,
    'imdb_rating'    => null,
    'language'       => $movie['original_language'] ?? null,
    'status'         => mapTmdbStatus($movie['status'] ?? ''),
    'budget'         => ($movie['budget'] ?? 0) ?: null,
    'revenue'        => ($movie['revenue'] ?? 0) ?: null,
]);

 
foreach ($movie['genres'] ?? [] as $g) {
    $slug  = preg_replace('/[^a-z0-9-]/', '-', strtolower($g['name']));
    $genre = dbFetch("SELECT id FROM genres WHERE name = :name OR slug = :slug", ['name' => $g['name'], 'slug' => $slug]);
    if (!$genre) {
        $gid = dbInsert('genres', ['name' => $g['name'], 'slug' => $slug]);
    } else {
        $gid = $genre['id'];
    }
    dbInsert('movie_genres', ['movie_id' => $movieId, 'genre_id' => $gid]);
}

 
foreach ($movie['credits']['crew'] ?? [] as $person) {
    if ($person['job'] !== 'Director') continue;
    $dir = dbFetch("SELECT id FROM directors WHERE tmdb_id = :tid", ['tid' => $person['id']]);
    if (!$dir) {
        $dirId = dbInsert('directors', [
            'name'     => $person['name'],
            'photo_url'=> $person['profile_path'] ? TMDB_IMAGE_URL . 'w185' . $person['profile_path'] : null,
            'tmdb_id'  => $person['id'],
        ]);
    } else {
        $dirId = $dir['id'];
    }
    if (!dbExists('movie_directors', ['movie_id' => $movieId, 'director_id' => $dirId])) {
        dbInsert('movie_directors', ['movie_id' => $movieId, 'director_id' => $dirId]);
    }
}

 
$castImported = 0;
foreach ($movie['credits']['cast'] ?? [] as $person) {
    if ($castImported >= 10) break;
    $actor = dbFetch("SELECT id FROM actors WHERE tmdb_id = :tid", ['tid' => $person['id']]);
    if (!$actor) {
        $actorId = dbInsert('actors', [
            'name'     => $person['name'],
            'photo_url'=> $person['profile_path'] ? TMDB_IMAGE_URL . 'w185' . $person['profile_path'] : null,
            'tmdb_id'  => $person['id'],
        ]);
    } else {
        $actorId = $actor['id'];
    }
    if (!dbExists('movie_actors', ['movie_id' => $movieId, 'actor_id' => $actorId])) {
        dbInsert('movie_actors', [
            'movie_id'       => $movieId,
            'actor_id'       => $actorId,
            'character_name' => sanitizeString($person['character'] ?? '', 200),
            'actor_order'    => $castImported,
        ]);
        $castImported++;
    }
}

jsonResponse(['ok' => true, 'id' => $movieId, 'title' => $movie['title'] ?? '']);

 
 
 
function tmdbRequest(string $endpoint, array $params = []): ?array {
    $GLOBALS['tmdb_last_error'] = '';
    $params['api_key'] = TMDB_API_KEY;

    [$status, $raw, $transportError] = tmdbHttpGet(tmdbBuildUrl(TMDB_BASE_URL, $endpoint, $params));
    if (($raw === null || $raw === '') && defined('TMDB_FALLBACK_BASE_URL') && TMDB_FALLBACK_BASE_URL) {
        $primaryError = $transportError ?: 'empty response';
        [$fallbackStatus, $fallbackRaw, $fallbackError] = tmdbHttpGet(tmdbBuildUrl(TMDB_FALLBACK_BASE_URL, $endpoint, $params));
        if ($fallbackRaw !== null && $fallbackRaw !== '') {
            $status = $fallbackStatus;
            $raw = $fallbackRaw;
            $transportError = '';
        } else {
            $transportError = trim($primaryError . '; fallback failed: ' . ($fallbackError ?: 'empty response'), '; ');
        }
    }

    if ($raw === null || $raw === '') {
        $GLOBALS['tmdb_last_error'] = $transportError ?: 'empty response';
        return null;
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        $GLOBALS['tmdb_last_error'] = 'invalid JSON response';
        return null;
    }

    if ($status < 200 || $status >= 300) {
        $message = $data['status_message'] ?? 'HTTP ' . $status;
        $code = isset($data['status_code']) ? ' #' . $data['status_code'] : '';
        $GLOBALS['tmdb_last_error'] = trim($message . $code . ' (HTTP ' . $status . ')');
        return null;
    }

    if (!empty($data['success']) && $data['success'] === false) {
        $GLOBALS['tmdb_last_error'] = $data['status_message'] ?? 'TMDB API error';
        return null;
    }

    return $data;
}

function tmdbBuildUrl(string $baseUrl, string $endpoint, array $params): string {
    $endpoint = '/' . ltrim($endpoint, '/');

    // Если базовый URL — это PHP-прокси (api/tmdb-proxy.php), передаём endpoint
    // отдельным параметром __path: на nginx PATH_INFO после «.php» не работает.
    $basePath = (string)(parse_url($baseUrl, PHP_URL_PATH) ?? '');
    if (str_ends_with(strtolower($basePath), '.php')) {
        $params = ['__path' => $endpoint] + $params;
        return $baseUrl . '?' . http_build_query($params);
    }

    return rtrim($baseUrl, '/') . $endpoint . '?' . http_build_query($params);
}

function tmdbHttpGet(string $url): array {
    if (function_exists('curl_init')) {
        $first = tmdbCurlGet($url);
        if ($first[1] !== null || !tmdbShouldRetryCurlError($first[2])) {
            return $first;
        }

        $retryOptions = [];
        if (defined('CURLOPT_IPRESOLVE') && defined('CURL_IPRESOLVE_V4')) {
            $retryOptions[CURLOPT_IPRESOLVE] = CURL_IPRESOLVE_V4;
        }
        if (defined('CURLOPT_HTTP_VERSION') && defined('CURL_HTTP_VERSION_1_1')) {
            $retryOptions[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
        }
        if (defined('CURLOPT_SSLVERSION') && defined('CURL_SSLVERSION_TLSv1_2')) {
            $retryOptions[CURLOPT_SSLVERSION] = CURL_SSLVERSION_TLSv1_2;
        }
        if (defined('CURLOPT_SSL_ENABLE_ALPN')) {
            $retryOptions[CURLOPT_SSL_ENABLE_ALPN] = false;
        }

        $second = tmdbCurlGet($url, $retryOptions);
        if ($second[1] !== null) {
            return $second;
        }

        $error = trim($first[2] . '; retry failed: ' . $second[2], '; ');
        return [$second[0] ?: $first[0], null, $error];
    }

    $ctx = stream_context_create([
        'http' => [
            'timeout' => 20,
            'ignore_errors' => true,
            'user_agent' => 'KinoDB TMDB importer',
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);

    $raw = @file_get_contents($url, false, $ctx);
    $status = 0;
    foreach ($http_response_header ?? [] as $header) {
        if (preg_match('#^HTTP/\S+\s+(\d+)#', $header, $m)) {
            $status = (int)$m[1];
        }
    }

    return [$status, $raw === false ? null : $raw, $raw === false ? 'file_get_contents failed' : ''];
}

function tmdbCurlGet(string $url, array $extraOptions = []): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_USERAGENT => 'KinoDB TMDB importer',
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_ENCODING => '',
    ] + $extraOptions);

    $raw = curl_exec($ch);
    $error = curl_error($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);

    return [$status, $raw === false ? null : $raw, $error];
}

function tmdbShouldRetryCurlError(string $error): bool {
    $error = strtolower($error);
    return str_contains($error, 'ssl')
        || str_contains($error, 'tls')
        || str_contains($error, 'unrecognized name')
        || str_contains($error, 'http/2')
        || str_contains($error, 'connection');
}

function tmdbLastError(): string {
    return (string)($GLOBALS['tmdb_last_error'] ?? '');
}

function mapTmdbStatus(string $status): string {
    return match($status) {
        'Released'      => 'released',
        'In Production',
        'Post Production'=> 'in_production',
        'Planned',
        'Announced'     => 'upcoming',
        'Cancelled'     => 'cancelled',
        default         => 'released',
    };
}
