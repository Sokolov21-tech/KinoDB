# KinoDB — Описание алгоритмов

## 1. Полнотекстовый поиск фильмов

**Файл:** `includes/functions.php` → `searchMovies()`

Используется **FULLTEXT-индекс MySQL** по полям `title`, `original_title`, `description`:

```sql
CREATE FULLTEXT INDEX ft_movies_search ON movies(title, original_title, description);
```

Запрос использует режим `IN BOOLEAN MODE`, что позволяет применять операторы:

```php
$term = '+' . implode('* +', preg_split('/\s+/', trim($q))) . '*';
// Пример: "крёстный отец" → "+крёстный* +отец*"
```

- `+слово` — слово **обязательно** должно присутствовать.
- `слово*` — поиск по **префиксу** (трамп → трамплин, трамп и т.д.).

**Fallback:** если FULLTEXT вернул 0 результатов, применяется `LIKE '%q%'` для коротких запросов.

**Фильтры** формируются динамически через массив `$where`:

```
жанр → подзапрос EXISTS(movie_genres JOIN genres WHERE slug = :genre)
год → m.release_year BETWEEN :year_from AND :year_to
страна → c.code = :country
рейтинг → AVG(ratings.rating) >= :min
```

**Сортировка** — из белого списка `$allowedSorts` (защита от SQL-инъекций через динамическое ORDER BY).

---

## 2. Система рейтингов

**Файл:** `includes/functions.php` → `getMovieAvgRating()`, `getMovieRatingDistribution()`

Пользователи ставят оценку 1–10. Средняя оценка вычисляется как **среднее арифметическое** всех оценок:

```sql
SELECT AVG(rating) FROM ratings WHERE movie_id = :id
```

**UPSERT рейтинга** (`api/rate.php`):

```
IF EXISTS(user_id + movie_id) → UPDATE
ELSE → INSERT
```

Используется ограничение `UNIQUE KEY uq_user_movie (user_id, movie_id)` в БД, что гарантирует один голос от пользователя.

**Распределение оценок** для гистограммы:

```sql
SELECT rating, COUNT(*) AS cnt FROM ratings
WHERE movie_id = :id GROUP BY rating
```

Результат приводится к массиву `[1..10 => count]`, ширина столбца вычисляется как `count / max_count * 100%`.

---

## 3. TOTP — Двухфакторная аутентификация (RFC 6238)

**Файл:** `includes/auth.php` → класс `TOTP`

### Алгоритм генерации кода

1. **Секрет** — 16 символов Base32 (80 бит случайных данных).
2. **Счётчик** — `floor(time() / 30)` — текущий 30-секундный интервал.
3. **HMAC** — `HMAC-SHA1(base32_decode(secret), pack('N*', 0) . pack('N*', counter))`.
4. **Смещение** — `offset = last_byte & 0x0F`.
5. **Код** — 4 байта начиная с `offset`, маскируется: `& 0x7FFFFFFF`, затем `mod 10^6`.
6. Результат дополняется нулями слева до 6 цифр.

```php
$hash   = hash_hmac('sha1', $counter_bytes, $key, true);
$offset = ord($hash[19]) & 0x0F;
$code   = ((...) ) % 1_000_000;
```

### Проверка (с допуском ±30 сек)

```php
for ($drift = -1; $drift <= 1; $drift++) {
    if (hash_equals(getCode($secret, $t + $drift * 30), $input_code)) return true;
}
```

`hash_equals()` — сравнение с постоянным временем (защита от timing-атак).

---

## 4. Регистрация с подтверждением email

**Файл:** `includes/auth.php` → `register()`, `sendVerificationEmail()`, `verifyEmailToken()`

```
Пользователь → register() → INSERT users (is_verified=0)
             → sendVerificationEmail()
               → token = random_bytes(32) → hex (64 символа)
               → expires_at = NOW() + 24h
               → INSERT email_verifications
               → отправка email со ссылкой /verify-email.php?token=...

Пользователь → /verify-email.php?token=...
             → verifyEmailToken()
               → SELECT WHERE token=... AND expires_at > NOW()
               → UPDATE users SET is_verified=1
               → DELETE token
```

Токен — 32 байта криптографически случайных данных (256 бит), что делает перебор невозможным.

---

## 5. Система комментариев с вложенностью

**Файл:** `includes/functions.php` → `getMovieComments()`

Структура: **два уровня** — корневые комментарии и ответы (parent_id IS NOT NULL).

```
Шаг 1: SELECT корневые комментарии (parent_id IS NULL)
Шаг 2: Для каждого комментария → SELECT ответы (parent_id = comment.id)
```

**Лайки комментариев:**
- Таблица `comment_likes(user_id, comment_id)` — составной PK исключает дублирование.
- Денормализованный счётчик `comments.likes_count` обновляется атомарно:
  ```sql
  UPDATE comments SET likes_count = likes_count + 1 WHERE id = :id
  ```

---

## 6. Rate Limiting (скользящее окно)

**Файл:** `includes/security.php` → `checkRateLimit()`

```
Для каждого запроса:
  1. ip = getClientIp()
  2. windowStart = NOW() - window_seconds
  3. SELECT WHERE ip=ip AND endpoint=ep AND window_start >= windowStart
  4. IF NOT EXISTS → INSERT (count=1), разрешить
  5. IF count >= max → отклонить (HTTP 429)
  6. ELSE → UPDATE count+1, разрешить
  7. С вероятностью 1% → очистка устаревших записей
```

**Определение IP:**
1. Cloudflare `CF-Connecting-IP`
2. `X-Forwarded-For` (первый IP в цепочке)
3. `X-Real-IP`
4. `REMOTE_ADDR`

Используется только публичный IP (`FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE`).

---

## 7. Алгоритм импорта фильмов из TMDB

**Файл:** `api/import-movie.php`

```
Вход: tmdb_id
  ↓
GET /movie/{id}?append_to_response=credits,external_ids&language=ru-RU
  ↓
Маппинг страны → countries (INSERT если не существует)
  ↓
INSERT movies (title, description, poster_url, backdrop_url, imdb_id, ...)
  ↓
Жанры:
  для каждого genres[]:
    slug = lowercase(name)
    SELECT genres WHERE name=... OR slug=...
    INSERT если не найден
    INSERT movie_genres
  ↓
Режиссёры (crew WHERE job='Director'):
  SELECT directors WHERE tmdb_id=...
  INSERT если не найден (name, photo_url)
  INSERT movie_directors
  ↓
Актёры (cast, топ 10):
  SELECT actors WHERE tmdb_id=...
  INSERT если не найден
  INSERT movie_actors (character_name, actor_order)
```

---

## 8. Алгоритм поиска "Топ фильмов"

**Файл:** `includes/functions.php` → `getTopMovies()`

```sql
SELECT m.id, AVG(r.rating) AS avg_rating, COUNT(r.id) AS vote_count
FROM movies m JOIN ratings r ON r.movie_id = m.id
GROUP BY m.id
HAVING vote_count >= 3          -- фильтр надёжности: минимум 3 оценки
ORDER BY avg_rating DESC, vote_count DESC
LIMIT 10
```

Условие `HAVING vote_count >= 3` исключает фильмы с единственной высокой оценкой (байесовский принцип "байесовского среднего" в упрощённом виде).

---

## 9. Валидация форм ввода

### Серверная (PHP, `includes/security.php`)

| Данные           | Метод                                      |
|------------------|--------------------------------------------|
| Строки           | `sanitizeString()` → `trim() + strip_tags()` |
| Целые числа      | `sanitizeInt()` → `filter_var(FILTER_SANITIZE_NUMBER_INT)` |
| Email            | `sanitizeEmail()` + `validateEmail()` → `FILTER_VALIDATE_EMAIL` |
| URL              | `sanitizeUrl()` + `validateUrl()` → `FILTER_VALIDATE_URL` |
| Enum-значения    | `in_array($val, $whitelist, true)`         |
| Файлы            | `finfo::file()` (MIME по содержимому)      |

### Клиентская (JavaScript, `assets/js/main.js`)

- Валидация HTML5 атрибутами: `required`, `minlength`, `maxlength`, `pattern`, `type`.
- Визуальная индикация ошибок через классы CSS `.error` и `.form-error.show`.
- Индикатор надёжности пароля в реальном времени (5 уровней: очень слабый → отличный).
- Автоматическая отправка формы 2FA при вводе 6-й цифры.
