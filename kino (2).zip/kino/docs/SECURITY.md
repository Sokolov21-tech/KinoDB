## 1. Защита от SQL-инъекций

### Метод: PDO с подготовленными выражениями

Весь доступ к БД осуществляется через PDO с **именованными параметрами** — пользовательский ввод никогда не подставляется в строку запроса напрямую.

```php
// ПРАВИЛЬНО — параметр связывается отдельно
$stmt = db()->prepare("SELECT * FROM users WHERE email = :email");
$stmt->execute(['email' => $email]);

// НЕПРАВИЛЬНО — прямая вставка (в коде не используется)
// $db->query("SELECT * FROM users WHERE email = '$email'");
```

Вспомогательные функции `dbFetch()`, `dbFetchAll()`, `dbInsert()`, `dbUpdate()`, `dbDelete()` в `includes/db.php` принудительно используют только параметризованные запросы.

**Дополнительно:**
- `PDO::ATTR_EMULATE_PREPARES = false` — настоящие prepared statements на уровне драйвера MySQL.
- Белый список допустимых значений для динамических частей (поля сортировки, статусы) проверяется в PHP через `in_array()`.
- Пользовательский ввод проходит через `sanitizeString()` / `sanitizeInt()` / `sanitizeEmail()` из `includes/security.php`.

---

## 2. Защита от XSS (Cross-Site Scripting)

### Контекстное экранирование вывода

Все данные, выводимые в HTML, проходят через функцию `e()`:

```php
function e(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}
```

- Флаг `ENT_QUOTES` — экранирует как одинарные, так и двойные кавычки.
- Кодировка `UTF-8` задана явно — исключает атаки через многобайтные символы.
- Для JSON-вывода используется `eJson()` с флагами `JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP`.

### Content-Security-Policy

В файле `.htaccess` установлен заголовок:

```
Content-Security-Policy: default-src 'self'; script-src 'self' cdnjs.cloudflare.com fonts.googleapis.com api.qrserver.com; style-src 'self' 'unsafe-inline' fonts.googleapis.com fonts.gstatic.com; img-src * data:; font-src 'self' fonts.gstatic.com
```

### Загрузка файлов

- Тип файла проверяется через `finfo` (MIME по содержимому, не по расширению).
- Загруженные изображения сохраняются вне директорий со скриптами.
- Имена файлов генерируются с помощью `random_bytes()` — оригинальные имена не используются.

---

## 3. Защита от CSRF (Cross-Site Request Forgery)

Все изменяющие состояние формы используют CSRF-токен:

```php
// Генерация
function csrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Проверка
function csrfVerify(): void {
    $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(403);
        die(...);
    }
}
```

- Сравнение через `hash_equals()` — защита от атак по времени (timing attacks).
- AJAX-запросы передают токен в заголовке `X-CSRF-Token`.

---

## 4. Защита от DDoS-атак

### 4.1 Уровень приложения — Rate Limiting

В `includes/security.php` реализовано ограничение числа запросов на основе IP-адреса:

| Эндпоинт               | Лимит     | Окно   |
|------------------------|-----------|--------|
| Страницы сайта         | 120 req   | 60 сек |
| API-запросы            | 60 req    | 60 сек |
| Авторизация / регистрация | 10 req | 60 сек |
| Импорт TMDB            | 30 req    | 60 сек |

```php
function checkRateLimit(string $endpoint, int $max, int $window): bool {
    // БД-счётчик запросов per IP + endpoint в скользящем окне
}
```

При превышении лимита возвращается HTTP 429 `Too Many Requests`.

IP-адрес пользователя определяется с учётом заголовков `CF-Connecting-IP` и `X-Forwarded-For` (Cloudflare / проксирование), только если они содержат публичный IP.

### 4.2 Защита на уровне Apache (файл .htaccess)

```apache
# Ограничение размера запроса (10 МБ)
LimitRequestBody 10485760

# Только разрешённые HTTP-методы
<LimitExcept GET POST HEAD>
    deny from all
</LimitExcept>

# Скрытие Server header
ServerSignature Off
```

### 4.3 Защита от DDOS

1. **Cloudflare** — прокси перед сервером с встроенной защитой от DDoS уровней L3/L4/L7.
2. **fail2ban** — блокировка IP после N неудачных попыток входа на уровне iptables.
3. **mod_evasive** — модуль Apache для автоматической блокировки при flood-атаках.
4. **Nginx rate limiting** — `limit_req_zone` на уровне веб-сервера.
5. **CDN** — кеширование статических ресурсов снижает нагрузку при DDoS.

```nginx
# Пример Nginx: max 10 req/sec per IP на /api/
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
location /api/ {
    limit_req zone=api burst=20 nodelay;
}
```

---

## 5. Аутентификация и управление сессиями

### Пароли
- Хеширование: `password_hash($pw, PASSWORD_BCRYPT, ['cost' => 12])`.
- Автоматическая перехэширование при входе, если стоимость изменилась.
- Минимальные требования: 8 символов, заглавная буква, цифра.

### Сессии
- Имя cookie: `kino_sess`, флаги `HttpOnly`, `SameSite=Lax`.
- Идентификатор сессии регенерируется каждые 5 минут и при входе.
- Блокировка аккаунта после 5 неудачных попыток на 15 минут.

### Двухфакторная аутентификация (TOTP, RFC 6238)
- Секретный ключ 16 символов (80 бит энтропии) в Base32.
- Алгоритм: HMAC-SHA1 со скользящим окном ±1 период (±30 сек).
- 10 одноразовых резервных кодов на случай потери устройства.
- QR-код генерируется через сторонний API без хранения секрета на внешнем сервере.

---

## 6. Дополнительные меры

| Мера                         | Реализация                                              |
|------------------------------|--------------------------------------------------------|
| HTTPS redirect               | `.htaccess` (включить в production)                   |
| Скрытие версии PHP           | `expose_php = Off` в php.ini                          |
| Защита директорий            | `.htaccess`: `deny from all` в `/logs/`, `/includes/`|
| Аудит действий               | Таблица `audit_log` — все CRUD-операции администратора|
| Безопасные заголовки         | `X-Frame-Options`, `X-Content-Type-Options`, `HSTS`   |
| Токены сброса пароля         | `random_bytes(32)`, TTL 1 час, одноразовые            |
